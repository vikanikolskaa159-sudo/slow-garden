"use client";

import {
  useState,
  useSyncExternalStore,
  type FormEvent,
  type ReactNode,
} from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowUpRight,
  Leaf,
  Sprout,
  type LucideIcon,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  MAX_SEED_LENGTH,
  addSeed,
  formatSeedDate,
  getSeedsSnapshot,
  getServerSeedsSnapshot,
  seedPresets,
  subscribeSeeds,
  type Seed,
} from "@/lib/seeds";

const emptySubscribe = () => () => {};

function useIsClient() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

function createSeed(text: string): Seed {
  const id =
    typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;

  return {
    id,
    text: text.slice(0, MAX_SEED_LENGTH),
    plantedAt: new Date().toISOString(),
  };
}

type SeedBadgeProps = {
  icon: LucideIcon;
  children: ReactNode;
};

function SeedBadge({ icon: Icon, children }: SeedBadgeProps) {
  return (
    <Badge
      variant="secondary"
      className="h-auto gap-2 rounded-full px-3 py-1 text-xs font-normal tracking-wide"
    >
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {children}
    </Badge>
  );
}

export function SeedGarden() {
  const seeds = useSyncExternalStore(
    subscribeSeeds,
    getSeedsSnapshot,
    getServerSeedsSnapshot
  );
  const isReady = useIsClient();
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);
  const [customText, setCustomText] = useState("");
  const [justPlanted, setJustPlanted] = useState<Seed | null>(null);
  const [hint, setHint] = useState<string | null>(null);

  function handlePlant(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const custom = customText.trim();
    const text = custom.length > 0 ? custom : selectedPreset;

    if (!text) {
      setHint(
        "Можно выбрать близкое состояние или написать своё — как получится сегодня."
      );
      return;
    }

    const seed = createSeed(text);
    const saved = addSeed(seed);

    setSelectedPreset(null);
    setCustomText("");
    setHint(
      saved
        ? null
        : "Сад не смог сохранить семя в этом браузере. Оно останется здесь, пока страница открыта."
    );
    setJustPlanted(seed);
  }

  function startAnotherSeed() {
    setJustPlanted(null);
    setHint(null);
  }

  return (
    <div className="container mx-auto px-4 py-14 sm:py-20">
      <div className="mx-auto grid max-w-5xl gap-10 animate-in fade-in slide-in-from-bottom-4 duration-700 lg:grid-cols-[1.05fr_0.95fr] lg:items-start lg:gap-14">
        <div className="space-y-8">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            На главную, в сад
          </Link>

          <div className="space-y-5">
            <SeedBadge icon={Sprout}>начало пути</SeedBadge>
            <h1 className="font-heading text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
              Семена
            </h1>
            <p className="max-w-xl text-lg leading-relaxed text-muted-foreground">
              Здесь можно назвать то, с чем вы пришли. Не для отчёта и не для
              решения — просто чтобы оставить это в земле.
            </p>
          </div>

          <div
            id="plant"
            className="scroll-mt-24 rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm sm:p-8"
          >
            {justPlanted ? (
              <div
                role="status"
                className="animate-in fade-in slide-in-from-bottom-4 duration-500"
              >
                <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-accent/60 text-primary">
                    <Sprout className="h-7 w-7" aria-hidden="true" />
                  </div>
                  <div className="space-y-3">
                    <p className="font-heading text-2xl leading-snug">
                      Семя уже в земле
                    </p>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      Вы оставили в саду: «{justPlanted.text}».
                    </p>
                  </div>
                </div>

                <div className="mt-6 space-y-3 border-t border-border/60 pt-5 text-sm leading-relaxed text-foreground/85">
                  <p>
                    Ему не нужно всходить быстро. Можно просто знать, что оно
                    там, — под землёй, в своём времени.
                  </p>
                  <p className="text-muted-foreground">
                    Возвращайтесь, когда захочется. Сад не ждёт и не считает
                    дни.
                  </p>
                </div>

                {hint ? (
                  <p className="mt-5 rounded-2xl border border-primary/15 bg-accent/35 px-4 py-3 text-sm leading-relaxed text-foreground/85">
                    {hint}
                  </p>
                ) : null}

                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <Button type="button" onClick={startAnotherSeed}>
                    <Sprout className="h-4 w-4" aria-hidden="true" />
                    Посадить ещё одно семя
                  </Button>
                  <a
                    href="#garden"
                    className="inline-flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    Заглянуть в сад
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handlePlant} className="space-y-6">
                <div className="space-y-2">
                  <h2 className="font-heading text-2xl leading-snug">
                    С чем вы пришли?
                  </h2>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    Выберите близкое состояние или опишите своё. Правильного
                    ответа здесь нет.
                  </p>
                </div>

                <div className="space-y-2.5">
                  <p
                    id="seed-presets-label"
                    className="text-xs uppercase tracking-[0.18em] text-primary/80"
                  >
                    готовые варианты
                  </p>
                  <div
                    role="group"
                    aria-labelledby="seed-presets-label"
                    className="flex flex-wrap gap-2"
                  >
                    {seedPresets.map((preset) => {
                      const isSelected = selectedPreset === preset;

                      return (
                        <button
                          key={preset}
                          type="button"
                          aria-pressed={isSelected}
                          onClick={() => {
                            setSelectedPreset(isSelected ? null : preset);
                            setHint(null);
                          }}
                          className={cn(
                            "rounded-full border px-4 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60",
                            isSelected
                              ? "border-primary bg-primary text-primary-foreground shadow-sm"
                              : "border-border/80 bg-background/60 text-foreground hover:border-primary/30 hover:bg-accent/50"
                          )}
                        >
                          {preset}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="seed-custom-text"
                    className="text-xs uppercase tracking-[0.18em] text-primary/80"
                  >
                    или своими словами
                  </label>
                  <Textarea
                    id="seed-custom-text"
                    value={customText}
                    maxLength={MAX_SEED_LENGTH}
                    onChange={(event) => {
                      setCustomText(event.target.value);
                      setHint(null);
                    }}
                    placeholder="Например: «устала держать всё под контролем»"
                    className="min-h-24 resize-none bg-background/60 text-base sm:text-sm"
                  />
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Достаточно нескольких слов. Можно и одно.
                  </p>
                </div>

                {hint ? (
                  <p
                    role="status"
                    className="rounded-2xl border border-primary/15 bg-accent/35 px-4 py-3 text-sm leading-relaxed text-foreground/85"
                  >
                    {hint}
                  </p>
                ) : null}

                <div className="flex flex-wrap items-center gap-3">
                  <Button type="submit">
                    <Sprout className="h-4 w-4" aria-hidden="true" />
                    Посадить семя
                  </Button>
                  {customText.trim().length > 0 ? (
                    <span className="text-xs text-muted-foreground">
                      будет посажено ваше описание
                    </span>
                  ) : null}
                </div>
              </form>
            )}
          </div>
        </div>

        <section
          id="garden"
          aria-labelledby="seed-garden-title"
          className="scroll-mt-24 space-y-5"
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary/80">
              <Leaf className="h-4 w-4" aria-hidden="true" />
              <p className="text-xs uppercase tracking-[0.18em]">мой сад</p>
            </div>
            <h2
              id="seed-garden-title"
              className="font-heading text-2xl leading-snug"
            >
              Посаженные семена
            </h2>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Здесь тихо лежат семена, которые вы уже оставили. Их не нужно
              поливать по расписанию.
            </p>
          </div>

          {!isReady ? (
            <div className="space-y-3" aria-hidden="true">
              <Skeleton className="h-24 w-full rounded-2xl" />
              <Skeleton className="h-24 w-full rounded-2xl" />
            </div>
          ) : seeds.length === 0 ? (
            <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-border/80 bg-card/50 px-6 py-10 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <Sprout className="h-6 w-6" aria-hidden="true" />
              </div>
              <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
                Здесь пока тихо. Первое семя можно посадить выше — когда будет
                удобно.
              </p>
              <a
                href="#plant"
                className={cn(
                  buttonVariants({ variant: "outline", size: "sm" })
                )}
              >
                Посадить семя
              </a>
            </div>
          ) : (
            <ul className="space-y-3">
              {seeds.map((seed) => (
                <li
                  key={seed.id}
                  className="flex gap-4 rounded-2xl border border-border/70 bg-card/70 p-4 shadow-sm sm:p-5"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent/50 text-primary">
                    <Sprout className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <p className="font-heading text-base leading-snug break-words">
                      {seed.text}
                    </p>
                    <p className="text-xs leading-relaxed text-muted-foreground">
                      посажено {formatSeedDate(seed.plantedAt)}
                    </p>
                  </div>
                  <span className="hidden shrink-0 self-start rounded-full bg-secondary px-2.5 py-1 text-[0.7rem] text-secondary-foreground sm:inline">
                    в земле
                  </span>
                </li>
              ))}
            </ul>
          )}

          <p className="text-xs leading-relaxed text-muted-foreground">
            Семена остаются в этом браузере. Когда вернётесь, сад будет на
            месте.
          </p>
        </section>
      </div>
    </div>
  );
}
