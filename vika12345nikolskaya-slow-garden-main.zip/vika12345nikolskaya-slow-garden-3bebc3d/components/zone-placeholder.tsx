import Link from "next/link";
import { ArrowLeft, Sprout, type LucideIcon } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import type { GardenZone } from "@/lib/garden";

type ZonePlaceholderProps = {
  zone: GardenZone;
  icon: LucideIcon;
};

export function ZonePlaceholder({ zone, icon: Icon }: ZonePlaceholderProps) {
  return (
    <div className="container mx-auto px-4 py-16 sm:py-24">
      <div className="mx-auto max-w-2xl space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          На главную, в сад
        </Link>

        <div className="space-y-5">
          <Badge
            variant="secondary"
            className="h-auto gap-2 rounded-full px-3 py-1 text-xs font-normal tracking-wide"
          >
            <Icon className="h-3.5 w-3.5" aria-hidden="true" />
            {zone.role}
          </Badge>
          <h1 className="font-heading text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
            {zone.name}
          </h1>
          <p className="max-w-xl text-lg leading-relaxed text-muted-foreground">
            {zone.description}
          </p>
        </div>

        <div className="rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm sm:p-8">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-accent/60 text-accent-foreground">
              <Sprout className="h-6 w-6" aria-hidden="true" />
            </div>
            <div className="space-y-2">
              <p className="font-heading text-xl">Эта зона ещё прорастает</p>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {zone.promise} Пока можно вернуться на карту сада или заглянуть
                в другую зону — порядок не важен.
              </p>
            </div>
          </div>
        </div>

        <p className="text-sm leading-relaxed text-muted-foreground">
          Сад не опаздывает — у каждой зоны свой срок. И вы можете возвращаться
          сюда, когда захочется.
        </p>
      </div>
    </div>
  );
}
