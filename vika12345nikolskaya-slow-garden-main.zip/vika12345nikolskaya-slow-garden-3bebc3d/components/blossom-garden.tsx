"use client";

import {
  useState,
  useSyncExternalStore,
  type FormEvent,
  type ReactNode,
} from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowUpRight,
  Feather,
  Flower2,
  Leaf,
  PenLine,
  Sprout,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  MAX_BLOSSOM_LENGTH,
  addBlossomNote,
  blossomStories,
  formatBlossomDate,
  getBlossomNotesSnapshot,
  getServerBlossomNotesSnapshot,
  subscribeBlossomNotes,
  type BlossomNote,
} from "@/lib/blossoms";

const emptySubscribe = () => () => {};

function useIsClient() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

function createNote(text: string): BlossomNote {
  const id =
    typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;

  return {
    id,
    text: text.slice(0, MAX_BLOSSOM_LENGTH),
    createdAt: new Date().toISOString(),
  };
}

type BlossomBadgeProps = {
  icon: LucideIcon;
  children: ReactNode;
};

function BlossomBadge({ icon: Icon, children }: BlossomBadgeProps) {
  return (
    <Badge
      variant="secondary"
      className="h-auto gap-2 rounded-full px-3 py-1 text-xs font-normal tracking-wide"
    >
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {children}
    </Badge>
  );
}

function PressedFlower() {
  return (
    <div
      className="relative hidden items-center justify-center lg:flex"
      aria-hidden="true"
    >
      <div className="absolute inset-0 rounded-[3rem] bg-accent/30 blur-2xl" />
      <div className="relative rotate-3 rounded-[2rem] border border-border/70 bg-card/70 p-5 shadow-[0_24px_50px_-30px_rgba(58,74,54,0.4)]">
        <svg viewBox="0 0 160 200" className="h-44 w-36">
          <g stroke="#7f9677" strokeWidth="2" strokeLinecap="round" fill="none">
            <path d="M80 188 C80 150 78 120 82 84" />
            <path d="M80 148 C66 138 56 128 50 112" />
            <path d="M82 126 C96 116 106 104 110 88" />
            <path d="M80 166 C70 160 62 154 58 144" />
          </g>
          <g fill="#a9bda0">
            <ellipse
              cx="58"
              cy="140"
              rx="13"
              ry="6"
              transform="rotate(-38 58 140)"
            />
            <ellipse
              cx="104"
              cy="116"
              rx="13"
              ry="6"
              transform="rotate(34 104 116)"
            />
            <ellipse
              cx="68"
              cy="164"
              rx="10"
              ry="5"
              transform="rotate(-30 68 164)"
            />
          </g>
          <g fill="#d6b7a8">
            <ellipse
              cx="82"
              cy="62"
              rx="10"
              ry="22"
              transform="rotate(0 82 62)"
            />
            <ellipse
              cx="82"
              cy="62"
              rx="10"
              ry="22"
              transform="rotate(60 82 62)"
            />
            <ellipse
              cx="82"
              cy="62"
              rx="10"
              ry="22"
              transform="rotate(120 82 62)"
            />
          </g>
          <circle cx="82" cy="62" r="8" fill="#e9d6a4" />
          <g fill="#c9d3bd" opacity="0.8">
            <circle cx="44" cy="88" r="2" />
            <circle cx="120" cy="72" r="2" />
            <circle cx="126" cy="150" r="1.8" />
          </g>
        </svg>
        <p className="mt-2 text-center text-[0.7rem] uppercase tracking-[0.2em] text-muted-foreground">
          гербарий наблюдений
        </p>
      </div>
    </div>
  );
}

export function BlossomGarden() {
  const notes = useSyncExternalStore(
    subscribeBlossomNotes,
    getBlossomNotesSnapshot,
    getServerBlossomNotesSnapshot
  );
  const isReady = useIsClient();
  const [text, setText] = useState("");
  const [hint, setHint] = useState<string | null>(null);
  const [justAddedId, setJustAddedId] = useState<string | null>(null);

  function handleAdd(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const value = text.trim();

    if (value.length === 0) {
      setHint(
        "Можно оставить хотя бы несколько слов — про мысль, привычку или спокойный день."
      );
      return;
    }

    const note = createNote(value);
    const saved = addBlossomNote(note);

    setText("");
    setJustAddedId(note.id);
    setHint(null);

    if (saved) {
      toast.success("Заметка легла в гербарий", {
        description: "Она сохранится в этом браузере и будет рядом.",
      });
    } else {
      toast.error("Браузер не сохранил заметку", {
        description: "Она останется здесь, пока страница открыта.",
      });
    }
  }

  return (
    <div className="container mx-auto px-4 py-14 sm:py-20">
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          На главную, в сад
        </Link>

        <div className="grid gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div className="space-y-5">
            <BlossomBadge icon={Flower2}>истории прогресса</BlossomBadge>
            <h1 className="font-heading text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
              Цветение
            </h1>
            <p className="max-w-2xl text-lg leading-relaxed text-muted-foreground">
              Здесь собраны маленькие сдвиги — не по плану, а сами. Мысль,
              привычка, спокойный день. Их не нужно взвешивать и сравнивать:
              достаточно заметить, что они выросли.
            </p>
            <p className="max-w-xl border-l-2 border-primary/35 pl-4 text-base leading-relaxed text-foreground/85">
              То, что выросло само, — уже настоящий прогресс. Даже если выглядит
              тихо.
            </p>
          </div>

          <PressedFlower />
        </div>
      </div>

      <section
        aria-labelledby="stories-title"
        className="mt-14 scroll-mt-24 space-y-6"
      >
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div className="space-y-2">
            <p className="text-xs uppercase tracking-[0.24em] text-primary/80">
              чужие наблюдения
            </p>
            <h2
              id="stories-title"
              className="font-heading text-2xl leading-snug sm:text-3xl"
            >
              Истории, которые выросли сами
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
            У каждого свой срок. Можно просто прочитать и заметить, где-то это
            отзывается.
          </p>
        </div>

        <ul className="grid gap-4 sm:grid-cols-2">
          {blossomStories.map((story) => (
            <li
              key={story.id}
              className="card-hover flex flex-col gap-4 rounded-3xl border border-border/70 bg-card/80 p-5 shadow-sm sm:p-6"
            >
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-accent/60 text-primary">
                    <Leaf className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {story.author}
                  </span>
                </div>
                <time className="text-xs leading-relaxed text-muted-foreground/80">
                  {story.dateLabel}
                </time>
              </div>
              <p className="text-sm leading-relaxed text-foreground/85">
                {story.text}
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section
        id="notes"
        aria-labelledby="my-notes-title"
        className="mt-16 scroll-mt-24 space-y-6"
      >
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-primary/80">
            <Flower2 className="h-4 w-4" aria-hidden="true" />
            <p className="text-xs uppercase tracking-[0.18em]">мой гербарий</p>
          </div>
          <h2
            id="my-notes-title"
            className="font-heading text-2xl leading-snug sm:text-3xl"
          >
            Что выросло у вас
          </h2>
          <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
            Заметка может быть про что угодно маленькое: мысль, которая стала
            мягче, привычка, которая появилась сама, или просто спокойный день.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-start lg:gap-10">
          <div className="rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm sm:p-7">
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <label
                  htmlFor="blossom-note"
                  className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-primary/80"
                >
                  <Feather className="h-3.5 w-3.5" aria-hidden="true" />
                  новая заметка
                </label>
                <Textarea
                  id="blossom-note"
                  value={text}
                  maxLength={MAX_BLOSSOM_LENGTH}
                  onChange={(event) => {
                    setText(event.target.value);
                    setHint(null);
                  }}
                  placeholder="Например: «сегодня впервые не стала себя торопить»"
                  className="min-h-32 resize-none bg-background/60 text-base leading-relaxed sm:text-sm"
                />
                <div className="flex items-center justify-between gap-3 text-xs leading-relaxed text-muted-foreground">
                  <span>Достаточно одного предложения.</span>
                  <span className="tabular-nums">
                    {text.length}/{MAX_BLOSSOM_LENGTH}
                  </span>
                </div>
              </div>

              {hint ? (
                <p
                  role="status"
                  className="rounded-2xl border border-primary/15 bg-accent/35 px-4 py-3 text-sm leading-relaxed text-foreground/85"
                >
                  {hint}
                </p>
              ) : null}

              <div className="flex flex-wrap items-center gap-3">
                <Button type="submit">
                  <PenLine className="h-4 w-4" aria-hidden="true" />
                  Оставить в гербарии
                </Button>
                <a
                  href="#notes-list"
                  className="text-xs text-muted-foreground transition-colors hover:text-foreground"
                >
                  заметки ниже
                </a>
              </div>
            </form>

            <p className="mt-5 border-t border-border/60 pt-4 text-xs leading-relaxed text-muted-foreground">
              Заметки хранятся только в этом браузере. Никому не отправляются и
              не превращаются в отчёт.
            </p>
          </div>

          <div id="notes-list" className="scroll-mt-24 space-y-4">
            {!isReady ? (
              <div className="space-y-3" aria-hidden="true">
                <Skeleton className="h-24 w-full rounded-2xl" />
                <Skeleton className="h-24 w-full rounded-2xl" />
              </div>
            ) : notes.length === 0 ? (
              <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-border/80 bg-card/50 px-6 py-10 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Flower2 className="h-6 w-6" aria-hidden="true" />
                </div>
                <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
                  Пока здесь тихо. Когда захочется заметить что-то маленькое,
                  оставьте первую заметку — она будет ждать вас здесь.
                </p>
                <a
                  href="#blossom-note"
                  className={cn(
                    buttonVariants({ variant: "outline", size: "sm" })
                  )}
                >
                  <Sprout className="h-4 w-4" aria-hidden="true" />
                  Заметить маленькое
                </a>
              </div>
            ) : (
              <ul className="space-y-3">
                {notes.map((note) => (
                  <li
                    key={note.id}
                    className={cn(
                      "flex gap-4 rounded-2xl border bg-card/70 p-4 shadow-sm transition-colors sm:p-5",
                      note.id === justAddedId
                        ? "border-primary/40 bg-accent/25"
                        : "border-border/70"
                    )}
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent/50 text-primary">
                      <Flower2 className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <div className="min-w-0 flex-1 space-y-2">
                      <p className="font-heading text-base leading-snug break-words">
                        {note.text}
                      </p>
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        замечено {formatBlossomDate(note.createdAt)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            {isReady && notes.length > 0 ? (
              <p className="text-xs leading-relaxed text-muted-foreground">
                Новые заметки остаются сверху. Возвращайтесь, когда захочется
                перечитать свой гербарий.
              </p>
            ) : null}

            <a
              href="#notes"
              className="inline-flex items-center gap-2 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              К форме заметки
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            </a>
          </div>
        </div>
      </section>

      <div className="mt-14 rounded-3xl border border-primary/15 bg-accent/35 px-6 py-6 text-center">
        <p className="font-heading text-lg leading-relaxed text-foreground sm:text-xl">
          Цвести — не значит успевать. Иногда достаточно заметить, что уже
          выросло.
        </p>
      </div>
    </div>
  );
}
