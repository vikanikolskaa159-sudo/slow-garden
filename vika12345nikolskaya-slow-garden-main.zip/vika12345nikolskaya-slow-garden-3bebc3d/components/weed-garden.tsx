"use client";

import {
  useState,
  useSyncExternalStore,
  type FormEvent,
  type ReactNode,
} from "react";
import Link from "next/link";
import { ArrowLeft, ArrowUpRight, Feather, Leaf, Sprout } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import {
  MAX_BELIEF_LENGTH,
  MAX_REFRAME_LENGTH,
  addWeedEntry,
  buildCustomResponse,
  findWeedBelief,
  formatWeedDate,
  getServerWeedEntriesSnapshot,
  getWeedEntriesSnapshot,
  subscribeWeedEntries,
  weedBeliefs,
  type WeedEntry,
} from "@/lib/weeds";

const emptySubscribe = () => () => {};

function useIsClient() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

type Preview = {
  belief: string;
  explanation: string;
  reframe: string;
  isCustom: boolean;
};

function createEntry(belief: string, reframe: string): WeedEntry {
  const id =
    typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;

  return {
    id,
    belief: belief.slice(0, MAX_BELIEF_LENGTH),
    reframe: reframe.slice(0, MAX_REFRAME_LENGTH),
    weededAt: new Date().toISOString(),
  };
}

type WeedBadgeProps = {
  icon: typeof Leaf;
  children: ReactNode;
};

function WeedBadge({ icon: Icon, children }: WeedBadgeProps) {
  return (
    <Badge
      variant="secondary"
      className="h-auto gap-2 rounded-full px-3 py-1 text-xs font-normal tracking-wide"
    >
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {children}
    </Badge>
  );
}

export function WeedGarden() {
  const entries = useSyncExternalStore(
    subscribeWeedEntries,
    getWeedEntriesSnapshot,
    getServerWeedEntriesSnapshot
  );
  const isReady = useIsClient();
  const [selectedBeliefId, setSelectedBeliefId] = useState<string | null>(null);
  const [customBelief, setCustomBelief] = useState("");
  const [hint, setHint] = useState<string | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [draftReframe, setDraftReframe] = useState("");
  const [isSaved, setIsSaved] = useState(false);

  function handleReveal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const custom = customBelief.trim();

    if (custom.length > 0) {
      const response = buildCustomResponse(custom);

      setPreview({
        belief: custom.slice(0, MAX_BELIEF_LENGTH),
        explanation: response.explanation,
        reframe: response.reframe,
        isCustom: true,
      });
      setDraftReframe(response.reframe);
      setIsSaved(false);
      setHint(null);
      return;
    }

    const preset = selectedBeliefId ? findWeedBelief(selectedBeliefId) : null;

    if (!preset) {
      setHint(
        "Можно выбрать близкое убеждение или написать своё — так, как оно звучит у вас."
      );
      return;
    }

    setPreview({
      belief: preset.belief,
      explanation: preset.explanation,
      reframe: preset.reframe,
      isCustom: false,
    });
    setDraftReframe(preset.reframe);
    setIsSaved(false);
    setHint(null);
  }

  function handleSave() {
    if (!preview) {
      return;
    }

    const reframe = draftReframe.trim();

    if (reframe.length === 0) {
      toast.error("Пока нечего оставить в саду", {
        description:
          "Можно написать хотя бы несколько слов — или оставить предложенные.",
      });
      return;
    }

    const saved = addWeedEntry(createEntry(preview.belief, reframe));

    setIsSaved(true);

    if (saved) {
      toast.success("Запись осталась в саду", {
        description: "Её можно перечитать здесь в любой момент.",
      });
    } else {
      toast.error("Браузер не сохранил запись", {
        description: "Она останется на этой странице, пока она открыта.",
      });
    }
  }

  function handleReset() {
    setPreview(null);
    setDraftReframe("");
    setIsSaved(false);
    setSelectedBeliefId(null);
    setCustomBelief("");
    setHint(null);
  }

  return (
    <div className="container mx-auto px-4 py-14 sm:py-20">
      <div className="mx-auto grid max-w-5xl gap-10 animate-in fade-in slide-in-from-bottom-4 duration-700 lg:grid-cols-[1.05fr_0.95fr] lg:items-start lg:gap-14">
        <div className="space-y-8">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            На главную, в сад
          </Link>

          <div className="space-y-5">
            <WeedBadge icon={Leaf}>работа с убеждениями</WeedBadge>
            <h1 className="font-heading text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
              Сорняки
            </h1>
            <p className="max-w-xl text-lg leading-relaxed text-muted-foreground">
              Иногда в саду разрастается мысль, которая мешает дышать. Её не
              обязательно вырывать с корнем — можно заметить и сказать мягче.
            </p>
          </div>

          <div
            id="belief"
            className="scroll-mt-24 rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm sm:p-8"
          >
            {preview ? (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="space-y-3">
                  <p className="text-xs uppercase tracking-[0.18em] text-primary/80">
                    {preview.isCustom ? "ваша мысль" : "замеченное убеждение"}
                  </p>
                  <blockquote className="border-l-2 border-primary/30 pl-4 font-heading text-xl leading-relaxed text-foreground/90 sm:text-2xl">
                    «{preview.belief}»
                  </blockquote>
                </div>

                <div className="space-y-2 rounded-2xl bg-accent/30 px-4 py-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-primary/80">
                    как это обычно работает
                  </p>
                  <p className="text-sm leading-relaxed text-foreground/85">
                    {preview.explanation}
                  </p>
                </div>

                <div className="space-y-2.5">
                  <label
                    htmlFor="weed-reframe"
                    className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-primary/80"
                  >
                    <Feather className="h-3.5 w-3.5" aria-hidden="true" />
                    мягче можно так
                  </label>
                  <Textarea
                    id="weed-reframe"
                    value={draftReframe}
                    maxLength={MAX_REFRAME_LENGTH}
                    onChange={(event) => {
                      setDraftReframe(event.target.value);
                      setIsSaved(false);
                    }}
                    className="min-h-28 resize-none bg-background/60 text-base leading-relaxed sm:text-sm"
                  />
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Это не новая обязанность и не обещание. Можно оставить как
                    есть или поправить под себя.
                  </p>
                </div>

                {isSaved ? (
                  <div
                    role="status"
                    className="space-y-3 rounded-2xl border border-primary/15 bg-accent/35 px-4 py-4"
                  >
                    <p className="font-heading text-lg leading-snug">
                      Выполото и оставлено в саду
                    </p>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      Теперь эта формулировка лежит рядом — её можно перечитать,
                      когда захочется.
                    </p>
                    <a
                      href="#weeded"
                      className="inline-flex items-center gap-2 text-sm text-primary transition-colors hover:text-primary/80"
                    >
                      Посмотреть в саду
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </a>
                  </div>
                ) : null}

                <div className="flex flex-wrap items-center gap-3">
                  {!isSaved ? (
                    <Button type="button" onClick={handleSave}>
                      <Sprout className="h-4 w-4" aria-hidden="true" />
                      Выполоть и оставить в саду
                    </Button>
                  ) : null}
                  <Button type="button" variant="outline" onClick={handleReset}>
                    Выбрать другое убеждение
                  </Button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleReveal} className="space-y-6">
                <div className="space-y-2">
                  <h2 className="font-heading text-2xl leading-snug">
                    Какая мысль мешает?
                  </h2>
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    Выберите то, что откликается, или опишите свою мысль. Это
                    останется между вами и этим садом.
                  </p>
                </div>

                <div className="space-y-2.5">
                  <p
                    id="weed-presets-label"
                    className="text-xs uppercase tracking-[0.18em] text-primary/80"
                  >
                    частые убеждения
                  </p>
                  <div
                    role="group"
                    aria-labelledby="weed-presets-label"
                    className="flex flex-wrap gap-2"
                  >
                    {weedBeliefs.map((item) => {
                      const isSelected = selectedBeliefId === item.id;

                      return (
                        <button
                          key={item.id}
                          type="button"
                          aria-pressed={isSelected}
                          onClick={() => {
                            setSelectedBeliefId(isSelected ? null : item.id);
                            setHint(null);
                          }}
                          className={cn(
                            "rounded-full border px-4 py-2 text-left text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60",
                            isSelected
                              ? "border-primary bg-primary text-primary-foreground shadow-sm"
                              : "border-border/80 bg-background/60 text-foreground hover:border-primary/30 hover:bg-accent/50"
                          )}
                        >
                          {item.belief}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="weed-custom-belief"
                    className="text-xs uppercase tracking-[0.18em] text-primary/80"
                  >
                    или своими словами
                  </label>
                  <Textarea
                    id="weed-custom-belief"
                    value={customBelief}
                    maxLength={MAX_BELIEF_LENGTH}
                    onChange={(event) => {
                      setCustomBelief(event.target.value);
                      setHint(null);
                    }}
                    placeholder="Например: «у меня ничего не получится»"
                    className="min-h-24 resize-none bg-background/60 text-base sm:text-sm"
                  />
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Можно написать так, как мысль звучит внутри. Красиво
                    формулировать не нужно.
                  </p>
                </div>

                {hint ? (
                  <p
                    role="status"
                    className="rounded-2xl border border-primary/15 bg-accent/35 px-4 py-3 text-sm leading-relaxed text-foreground/85"
                  >
                    {hint}
                  </p>
                ) : null}

                <div className="flex flex-wrap items-center gap-3">
                  <Button type="submit">
                    <Feather className="h-4 w-4" aria-hidden="true" />
                    Найти слова мягче
                  </Button>
                  {customBelief.trim().length > 0 ? (
                    <span className="text-xs text-muted-foreground">
                      будем работать с вашей формулировкой
                    </span>
                  ) : null}
                </div>
              </form>
            )}
          </div>
        </div>

        <section
          id="weeded"
          aria-labelledby="weed-garden-title"
          className="scroll-mt-24 space-y-5"
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary/80">
              <Leaf className="h-4 w-4" aria-hidden="true" />
              <p className="text-xs uppercase tracking-[0.18em]">
                выполотое в саду
              </p>
            </div>
            <h2
              id="weed-garden-title"
              className="font-heading text-2xl leading-snug"
            >
              Записи, к которым можно вернуться
            </h2>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Здесь лежат ваши переформулировки. Их не нужно перечитывать по
              расписанию — достаточно знать, что они рядом.
            </p>
          </div>

          {!isReady ? (
            <div className="space-y-3" aria-hidden="true">
              <Skeleton className="h-28 w-full rounded-2xl" />
              <Skeleton className="h-28 w-full rounded-2xl" />
            </div>
          ) : entries.length === 0 ? (
            <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-border/80 bg-card/50 px-6 py-10 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <Leaf className="h-6 w-6" aria-hidden="true" />
              </div>
              <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
                Пока здесь тихо. Когда захочется, можно заметить одну мысль и
                оставить рядом её более мягкую версию.
              </p>
              <a
                href="#belief"
                className={cn(
                  buttonVariants({ variant: "outline", size: "sm" })
                )}
              >
                Заглянуть к сорнякам
              </a>
            </div>
          ) : (
            <ul className="space-y-3">
              {entries.map((entry) => (
                <li
                  key={entry.id}
                  className="flex gap-4 rounded-2xl border border-border/70 bg-card/70 p-4 shadow-sm sm:p-5"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent/50 text-primary">
                    <Sprout className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <div className="min-w-0 flex-1 space-y-2">
                    <p className="text-xs leading-relaxed text-muted-foreground break-words">
                      было: «{entry.belief}»
                    </p>
                    <div className="space-y-1">
                      <p className="text-[0.7rem] uppercase tracking-[0.18em] text-primary/70">
                        теперь вместо этого
                      </p>
                      <p className="font-heading text-base leading-snug break-words">
                        {entry.reframe}
                      </p>
                    </div>
                    <p className="text-xs leading-relaxed text-muted-foreground">
                      записано {formatWeedDate(entry.weededAt)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}

          <p className="text-xs leading-relaxed text-muted-foreground">
            Записи остаются в этом браузере. Когда вернётесь, сад будет на
            месте.
          </p>
        </section>
      </div>
    </div>
  );
}
