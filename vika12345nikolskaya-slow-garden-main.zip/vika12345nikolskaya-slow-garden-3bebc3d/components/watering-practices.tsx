"use client";

import {
  useEffect,
  useMemo,
  useReducer,
  useState,
  useSyncExternalStore,
} from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  CircleCheck,
  Droplets,
  Pause,
  Play,
  Timer,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { practices, type Practice } from "@/lib/practices";
import { cn } from "@/lib/utils";
import {
  formatWateringDate,
  formatWeekday,
  getRecentDateKeys,
  getTodayKey,
  getWateringSnapshot,
  getWateringSummary,
  getServerWateringSnapshot,
  markWateredToday,
  pluralDays,
  subscribeWatering,
  type WateringSummary,
} from "@/lib/watering";

const emptySubscribe = () => () => {};

function useIsClient() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

function formatClock(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

type SessionState = {
  phase: "intro" | "steps" | "finished";
  stepIndex: number;
  secondsLeft: number;
  isRunning: boolean;
};

type SessionAction =
  | { type: "start"; seconds: number }
  | { type: "tick" }
  | { type: "set-running"; value: boolean }
  | { type: "go-to-step"; index: number; seconds: number }
  | { type: "finish" };

function sessionReducer(
  state: SessionState,
  action: SessionAction
): SessionState {
  switch (action.type) {
    case "start":
      return {
        phase: "steps",
        stepIndex: 0,
        secondsLeft: action.seconds,
        isRunning: action.seconds > 0,
      };
    case "tick":
      return { ...state, secondsLeft: Math.max(0, state.secondsLeft - 1) };
    case "set-running":
      return { ...state, isRunning: action.value };
    case "go-to-step":
      return {
        phase: "steps",
        stepIndex: action.index,
        secondsLeft: action.seconds,
        isRunning: action.seconds > 0,
      };
    case "finish":
      return { ...state, phase: "finished", isRunning: false };
    default:
      return state;
  }
}

type PracticeSessionProps = {
  practice: Practice;
  wateredToday: boolean;
  markHint: string | null;
  onClose: () => void;
  onMarkWatered: () => void;
};

function PracticeSession({
  practice,
  wateredToday,
  markHint,
  onClose,
  onMarkWatered,
}: PracticeSessionProps) {
  const [state, dispatch] = useReducer(sessionReducer, {
    phase: "intro",
    stepIndex: 0,
    secondsLeft: 0,
    isRunning: false,
  });
  const [note, setNote] = useState("");

  const step = practice.steps[state.stepIndex];
  const stepCount = practice.steps.length;
  const isLastStep = state.stepIndex === stepCount - 1;
  const stepSeconds = step?.seconds ?? 0;
  const Icon = practice.icon;

  useEffect(() => {
    if (state.phase !== "steps" || !state.isRunning) {
      return;
    }

    const currentStep = practice.steps[state.stepIndex];

    if (!currentStep?.seconds || state.secondsLeft <= 0) {
      return;
    }

    const timeout = window.setTimeout(() => {
      if (state.secondsLeft <= 1) {
        if (state.stepIndex >= practice.steps.length - 1) {
          dispatch({ type: "finish" });
          return;
        }

        const nextIndex = state.stepIndex + 1;

        dispatch({
          type: "go-to-step",
          index: nextIndex,
          seconds: practice.steps[nextIndex]?.seconds ?? 0,
        });
        return;
      }

      dispatch({ type: "tick" });
    }, 1000);

    return () => window.clearTimeout(timeout);
  }, [
    practice.steps,
    state.phase,
    state.isRunning,
    state.secondsLeft,
    state.stepIndex,
  ]);

  function startPractice() {
    dispatch({
      type: "start",
      seconds: practice.steps[0]?.seconds ?? 0,
    });
    setNote("");
  }

  function goToNextStep() {
    if (isLastStep) {
      dispatch({ type: "finish" });
      return;
    }

    const nextIndex = state.stepIndex + 1;

    dispatch({
      type: "go-to-step",
      index: nextIndex,
      seconds: practice.steps[nextIndex]?.seconds ?? 0,
    });
  }

  if (state.phase === "intro") {
    return (
      <div className="animate-in fade-in slide-in-from-bottom-4 rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm duration-500 sm:p-8">
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />К практикам
        </button>

        <div className="mt-6 flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-accent/60 text-primary">
            <Icon className="h-6 w-6" aria-hidden="true" />
          </div>
          <div className="space-y-2">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h2 className="font-heading text-2xl leading-snug">
                {practice.title}
              </h2>
              <Badge
                variant="secondary"
                className="h-auto rounded-full px-2.5 py-0.5 text-[0.7rem] font-normal"
              >
                {practice.duration}
              </Badge>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              {practice.description}
            </p>
          </div>
        </div>

        <div className="mt-6 rounded-2xl border border-border/60 bg-secondary/35 px-5 py-4 text-sm leading-relaxed text-foreground/85">
          <p>{practice.intro}</p>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button type="button" onClick={startPractice}>
            <Play className="h-4 w-4" aria-hidden="true" />
            Начать практику
          </Button>
          <span className="text-xs leading-relaxed text-muted-foreground">
            Можно остановиться в любой момент.
          </span>
        </div>
      </div>
    );
  }

  if (state.phase === "steps" && step) {
    const stepProgress =
      stepSeconds > 0
        ? Math.min(1, Math.max(0, 1 - state.secondsLeft / stepSeconds))
        : (state.stepIndex + 1) / stepCount;

    return (
      <div className="animate-in fade-in slide-in-from-bottom-4 rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm duration-500 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />К практикам
          </button>
          <Badge
            variant="secondary"
            className="h-auto rounded-full px-3 py-1 text-[0.7rem] font-normal"
          >
            Шаг {state.stepIndex + 1} из {stepCount}
          </Badge>
        </div>

        <div className="mt-6 flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-accent/60 text-primary">
            <Icon className="h-6 w-6" aria-hidden="true" />
          </div>
          <div className="space-y-2">
            <h2 className="font-heading text-2xl leading-snug">{step.title}</h2>
            <p className="text-base leading-relaxed text-foreground/85">
              {step.text}
            </p>
          </div>
        </div>

        {step.allowNote ? (
          <div className="mt-5 space-y-2">
            <label
              htmlFor={`practice-note-${practice.id}`}
              className="text-xs uppercase tracking-[0.18em] text-primary/80"
            >
              если хочется, запишите
            </label>
            <Textarea
              id={`practice-note-${practice.id}`}
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder={step.notePlaceholder}
              className="min-h-24 resize-none bg-background/60 text-base sm:text-sm"
            />
            <p className="text-xs leading-relaxed text-muted-foreground">
              Запись останется только на этой странице — её не нужно никому
              показывать.
            </p>
          </div>
        ) : null}

        <div className="mt-6 space-y-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {stepSeconds > 0 ? "мягкий таймер" : "можно не спешить"}
            </span>
            {stepSeconds > 0 ? (
              <span className="inline-flex items-center gap-1.5 tabular-nums">
                <Timer className="h-3.5 w-3.5" aria-hidden="true" />
                {formatClock(state.secondsLeft)}
              </span>
            ) : (
              <span>
                {state.stepIndex + 1} / {stepCount}
              </span>
            )}
          </div>
          <div
            className="h-1.5 w-full overflow-hidden rounded-full bg-secondary"
            role="progressbar"
            aria-label="Ход практики"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(stepProgress * 100)}
          >
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-1000 ease-linear"
              style={{ width: `${stepProgress * 100}%` }}
            />
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          {stepSeconds > 0 ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                dispatch({ type: "set-running", value: !state.isRunning })
              }
            >
              {state.isRunning ? (
                <Pause className="h-4 w-4" aria-hidden="true" />
              ) : (
                <Play className="h-4 w-4" aria-hidden="true" />
              )}
              {state.isRunning ? "Пауза" : "Продолжить"}
            </Button>
          ) : null}
          <Button type="button" onClick={goToNextStep}>
            {isLastStep ? "Завершить практику" : "Дальше"}
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Button>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg px-2 py-2 text-xs text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
          >
            Выйти, не завершая
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm duration-500 sm:p-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />К практикам
        </button>
        <Badge
          variant="secondary"
          className="h-auto gap-1.5 rounded-full px-3 py-1 text-[0.7rem] font-normal"
        >
          <CircleCheck className="h-3.5 w-3.5" aria-hidden="true" />
          практика завершена
        </Badge>
      </div>

      <div className="mt-6 flex flex-col gap-5 sm:flex-row sm:items-start">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-accent/60 text-primary">
          <Droplets className="h-7 w-7" aria-hidden="true" />
        </div>
        <div className="space-y-2">
          <h2 className="font-heading text-2xl leading-snug">
            Спасибо, что нашлось время
          </h2>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {practice.closing}
          </p>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-primary/15 bg-accent/35 p-5">
        {wateredToday ? (
          <p className="text-sm leading-relaxed text-foreground/85">
            Сегодня уже отмечено. Можно просто побыть с этим — без второго раза
            и без отчёта.
          </p>
        ) : (
          <div className="space-y-3">
            <p className="text-sm leading-relaxed text-foreground/85">
              Если хочется, отметьте, что сегодня сад полит. Это не обязанность
              — просто тихая отметка.
            </p>
            <Button type="button" onClick={onMarkWatered}>
              <Droplets className="h-4 w-4" aria-hidden="true" />
              Полил сегодня
            </Button>
          </div>
        )}

        {markHint ? (
          <p
            role="status"
            className="mt-3 text-xs leading-relaxed text-muted-foreground"
          >
            {markHint}
          </p>
        ) : null}
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <Button type="button" variant="outline" onClick={onClose}>
          Вернуться к практикам
        </Button>
      </div>
    </div>
  );
}

type WateringStatusProps = {
  summary: WateringSummary;
  recentKeys: string[];
  wateredDays: Set<string>;
  todayKey: string;
};

function WateringStatus({
  summary,
  recentKeys,
  wateredDays,
  todayKey,
}: WateringStatusProps) {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div
          className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
            summary.wateredToday
              ? "bg-primary text-primary-foreground"
              : "bg-accent/60 text-primary"
          )}
        >
          {summary.wateredToday ? (
            <CircleCheck className="h-5 w-5" aria-hidden="true" />
          ) : (
            <Droplets className="h-5 w-5" aria-hidden="true" />
          )}
        </div>
        <div>
          <p className="font-heading text-lg leading-snug">
            {summary.wateredToday
              ? "Сегодня полито"
              : "Сегодня пока без полива"}
          </p>
          <p className="text-xs text-muted-foreground">отметка одна на день</p>
        </div>
      </div>

      {summary.totalDays === 0 ? (
        <p className="text-sm leading-relaxed text-muted-foreground">
          Здесь пока тихо. Первый полив можно сделать, когда будет удобно —
          практика ни к чему не обязывает.
        </p>
      ) : (
        <div className="space-y-2.5">
          {summary.currentStreak > 0 ? (
            <div className="flex items-end gap-2">
              <span className="font-heading text-4xl leading-none">
                {summary.currentStreak}
              </span>
              <span className="pb-1 text-sm text-muted-foreground">
                {pluralDays(summary.currentStreak)} подряд
              </span>
            </div>
          ) : (
            <div className="flex items-end gap-2">
              <span className="font-heading text-4xl leading-none">
                {summary.totalDays}
              </span>
              <span className="pb-1 text-sm text-muted-foreground">
                {pluralDays(summary.totalDays)} с поливом
              </span>
            </div>
          )}

          <p className="text-sm leading-relaxed text-muted-foreground">
            {summary.wateredToday
              ? "Это просто наблюдение: сад не ведёт счёт и не ждёт серии."
              : summary.currentStreak > 0
                ? "Вчерашний полив никуда не делся. Сегодня можно присоединиться, когда захочется."
                : "История не обнуляется — в ней уже есть дни, когда вы поливали."}
          </p>

          <p className="text-xs leading-relaxed text-muted-foreground">
            Всего в истории: {summary.totalDays} {pluralDays(summary.totalDays)}
            .
          </p>
        </div>
      )}

      {summary.hasMissedDays ? (
        <div className="rounded-2xl border border-primary/15 bg-accent/35 px-4 py-3 text-sm leading-relaxed text-foreground/85">
          <p className="font-medium">Сад не сердится.</p>
          <p className="mt-1 text-muted-foreground">
            Дни без полива ничего не стирают: в истории уже {summary.totalDays}{" "}
            {pluralDays(summary.totalDays)}. Можно просто продолжить с сегодня —
            без упрёков и без «потерянного прогресса».
          </p>
        </div>
      ) : null}

      <div className="space-y-2 border-t border-border/60 pt-4">
        <p className="text-[0.68rem] uppercase tracking-[0.18em] text-primary/80">
          последние семь дней
        </p>
        <ul className="grid grid-cols-7 gap-1">
          {recentKeys.map((key) => {
            const watered = wateredDays.has(key);
            const isToday = key === todayKey;

            return (
              <li
                key={key}
                className="flex flex-col items-center gap-1"
                title={formatWateringDate(key)}
              >
                <span className="text-[0.62rem] text-muted-foreground">
                  {formatWeekday(key)}
                </span>
                <span
                  aria-label={
                    watered ? "был полив" : "без полива — это тоже нормально"
                  }
                  className={cn(
                    "flex h-7 w-7 items-center justify-center rounded-full border",
                    watered
                      ? "border-primary/30 bg-primary/10 text-primary"
                      : "border-dashed border-border/80 text-muted-foreground/40",
                    isToday && "ring-1 ring-primary/30"
                  )}
                >
                  <Droplets className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
              </li>
            );
          })}
        </ul>
      </div>

      {summary.lastDate ? (
        <p className="text-xs leading-relaxed text-muted-foreground">
          Последний полив —{" "}
          {summary.lastDate === todayKey
            ? "сегодня"
            : formatWateringDate(summary.lastDate)}
          .
        </p>
      ) : null}
    </div>
  );
}

type PracticeCardProps = {
  practice: Practice;
  onSelect: () => void;
};

function PracticeCard({ practice, onSelect }: PracticeCardProps) {
  const Icon: LucideIcon = practice.icon;

  return (
    <button
      type="button"
      onClick={onSelect}
      className="card-hover group flex w-full flex-col gap-4 rounded-3xl border border-border/70 bg-card/80 p-5 text-left shadow-sm transition-colors hover:border-primary/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 sm:p-6"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-accent/60 text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
          <Icon className="h-5.5 w-5.5" aria-hidden="true" />
        </div>
        <Badge
          variant="secondary"
          className="h-auto rounded-full px-2.5 py-0.5 text-[0.7rem] font-normal"
        >
          {practice.duration}
        </Badge>
      </div>

      <div className="space-y-1.5">
        <h3 className="font-heading text-xl leading-snug">{practice.title}</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          {practice.description}
        </p>
      </div>

      <span className="inline-flex items-center gap-2 text-sm font-medium text-primary">
        Открыть практику
        <ArrowRight
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          aria-hidden="true"
        />
      </span>
    </button>
  );
}

export function WateringPractices() {
  const dates = useSyncExternalStore(
    subscribeWatering,
    getWateringSnapshot,
    getServerWateringSnapshot
  );
  const isReady = useIsClient();
  const todayKey = getTodayKey();
  const summary = useMemo(
    () => getWateringSummary(dates, todayKey),
    [dates, todayKey]
  );
  const recentKeys = useMemo(() => getRecentDateKeys(todayKey, 7), [todayKey]);
  const wateredDays = useMemo(() => new Set(dates), [dates]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [markHint, setMarkHint] = useState<string | null>(null);

  const selectedPractice =
    practices.find((practice) => practice.id === selectedId) ?? null;

  function handleMarkWatered() {
    const result = markWateredToday();

    if (result.alreadyMarked) {
      toast("Сегодня уже отмечено — одного раза достаточно.");
      return;
    }

    if (!result.saved) {
      setMarkHint(
        "Отметка осталась на этой странице, но браузер не смог сохранить её. Это не страшно — сад не ведёт строгий учёт."
      );
      toast("Отметка есть, но сохранить её в браузере не удалось.");
      return;
    }

    setMarkHint(null);
    toast.success("Полив отмечен. Сад не торопится.");
  }

  return (
    <div className="container mx-auto max-w-5xl px-4 py-14 sm:py-20">
      <div className="space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          На главную, в сад
        </Link>

        <Badge
          variant="secondary"
          className="h-auto gap-2 rounded-full px-3 py-1 text-xs font-normal tracking-wide"
        >
          <Droplets className="h-3.5 w-3.5" aria-hidden="true" />
          ежедневные практики
        </Badge>

        <h1 className="font-heading text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
          Полив
        </h1>
        <p className="max-w-2xl text-lg leading-relaxed text-muted-foreground">
          Короткие практики на две-пять минут. Один маленький шаг сегодня — без
          обязанности и без расписания. Можно зайти, подышать и уйти.
        </p>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.08fr_0.72fr] lg:items-start lg:gap-12">
        <div className="min-w-0">
          {selectedPractice ? (
            <PracticeSession
              key={selectedPractice.id}
              practice={selectedPractice}
              wateredToday={summary.wateredToday}
              markHint={markHint}
              onClose={() => {
                setSelectedId(null);
                setMarkHint(null);
              }}
              onMarkWatered={handleMarkWatered}
            />
          ) : (
            <section
              id="practices"
              aria-labelledby="practices-title"
              className="scroll-mt-24 space-y-5"
            >
              <div className="space-y-2">
                <p className="text-xs uppercase tracking-[0.24em] text-primary/80">
                  выберите практику
                </p>
                <h2
                  id="practices-title"
                  className="font-heading text-2xl leading-snug sm:text-3xl"
                >
                  Маленькие способы побыть с собой
                </h2>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Не нужно выбирать «правильную». Откройте ту, к которой тянется
                  сейчас, — или закройте страницу и вернитесь позже.
                </p>
              </div>

              <div className="grid gap-4">
                {practices.map((practice) => (
                  <PracticeCard
                    key={practice.id}
                    practice={practice}
                    onSelect={() => {
                      setSelectedId(practice.id);
                      setMarkHint(null);
                    }}
                  />
                ))}
              </div>

              <p className="text-xs leading-relaxed text-muted-foreground">
                Практику можно поставить на паузу или оставить незавершённой.
                Отметка появляется после последнего шага и ставится один раз в
                день.
              </p>
            </section>
          )}
        </div>

        <aside className="space-y-4 lg:sticky lg:top-24">
          <div className="rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm">
            <div className="mb-4 flex items-center gap-2 text-primary/80">
              <Droplets className="h-4 w-4" aria-hidden="true" />
              <p className="text-xs uppercase tracking-[0.18em]">наблюдение</p>
            </div>
            <h2 className="font-heading text-2xl leading-snug">Мой полив</h2>
            <div className="mt-4">
              {!isReady ? (
                <div className="space-y-3" aria-hidden="true">
                  <div className="flex items-center gap-3">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-16 w-full rounded-2xl" />
                </div>
              ) : (
                <WateringStatus
                  summary={summary}
                  recentKeys={recentKeys}
                  wateredDays={wateredDays}
                  todayKey={todayKey}
                />
              )}
            </div>
          </div>

          <div className="rounded-3xl border border-border/70 bg-secondary/35 p-5 text-sm leading-relaxed text-muted-foreground">
            <p>
              Отметка хранится в этом браузере и не превращается в серию,
              которую нельзя терять.
            </p>
            {!selectedPractice ? (
              <a
                href="#practices"
                className={cn(
                  buttonVariants({ variant: "outline", size: "sm" }),
                  "mt-4 bg-background/60"
                )}
              >
                Выбрать практику
              </a>
            ) : null}
          </div>
        </aside>
      </div>
    </div>
  );
}
