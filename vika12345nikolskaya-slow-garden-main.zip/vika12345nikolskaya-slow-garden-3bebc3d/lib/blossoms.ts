export type BlossomStory = {
  id: string;
  author: string;
  text: string;
  dateLabel: string;
};

export type BlossomNote = {
  id: string;
  text: string;
  createdAt: string;
};

export const MAX_BLOSSOM_LENGTH = 280;

export const blossomStories: BlossomStory[] = [
  {
    id: "story-letter",
    author: "Мира",
    text: "Месяц не могла собраться написать одно письмо. Сегодня просто открыла черновик и написала две строки. Ничего не отправила — но страх стал тише.",
    dateLabel: "14 ноября, 9:40",
  },
  {
    id: "story-morning",
    author: "Аня",
    text: "Перестала ждать, что утро начнётся с энергии. Поставила чашку у окна и пять минут молчала. День не стал идеальным, но стал моим.",
    dateLabel: "12 ноября, 7:55",
  },
  {
    id: "story-phone",
    author: "Тимур",
    text: "Заметил, что уже неделю не проверяю телефон первым делом после пробуждения. Не специально. Просто тело перестало так спешить.",
    dateLabel: "9 ноября",
  },
  {
    id: "story-tempo",
    author: "Лена",
    text: "Раньше злилась на себя за медленный темп. Вчера поймала мысль «ну и пусть» — и впервые не стала с ней спорить.",
    dateLabel: "5 ноября, 21:10",
  },
  {
    id: "story-walk",
    author: "Дима",
    text: "Вышел на прогулку без цели и без шагомера. Вернулся с ощущением, что что-то отпустило само. Я для этого ничего особенного не делал.",
    dateLabel: "2 ноября, 18:20",
  },
  {
    id: "story-no",
    author: "Соня",
    text: "Сказала «нет» работе в выходной. Весь день ждала, что станет тревожно, — а стало тихо. Оказалось, мир не рассыпался.",
    dateLabel: "30 октября",
  },
];

export function isBlossomNote(value: unknown): value is BlossomNote {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const note = value as Record<string, unknown>;

  return (
    typeof note.id === "string" &&
    typeof note.text === "string" &&
    typeof note.createdAt === "string"
  );
}

export function formatBlossomDate(isoDate: string): string {
  const date = new Date(isoDate);

  if (Number.isNaN(date.getTime())) {
    return "дата не записалась";
  }

  const day = new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
  }).format(date);

  const time = new Intl.DateTimeFormat("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);

  return `${day}, ${time}`;
}

function sortNotes(notes: BlossomNote[]): BlossomNote[] {
  return [...notes].sort(
    (a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)
  );
}

const BLOSSOMS_STORAGE_KEY = "sad-tsvetenie-v1";
const BLOSSOMS_UPDATED_EVENT = "sad-tsvetenie-updated";
const EMPTY_NOTES: BlossomNote[] = [];

let cachedNotes: BlossomNote[] = EMPTY_NOTES;
let isInitialized = false;

function parseNotes(raw: string | null): BlossomNote[] {
  if (!raw) {
    return EMPTY_NOTES;
  }

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed)
      ? sortNotes(parsed.filter(isBlossomNote))
      : EMPTY_NOTES;
  } catch {
    return EMPTY_NOTES;
  }
}

function readNotesFromStorage(): BlossomNote[] {
  try {
    return parseNotes(window.localStorage.getItem(BLOSSOMS_STORAGE_KEY));
  } catch {
    return EMPTY_NOTES;
  }
}

function ensureInitialized() {
  if (isInitialized) {
    return;
  }

  cachedNotes = readNotesFromStorage();
  isInitialized = true;
}

export function subscribeBlossomNotes(onChange: () => void): () => void {
  ensureInitialized();

  const handleStorage = (event: StorageEvent) => {
    if (event.key !== null && event.key !== BLOSSOMS_STORAGE_KEY) {
      return;
    }

    cachedNotes = parseNotes(event.newValue);
    onChange();
  };

  const handleUpdate = () => {
    onChange();
  };

  window.addEventListener("storage", handleStorage);
  window.addEventListener(BLOSSOMS_UPDATED_EVENT, handleUpdate);

  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(BLOSSOMS_UPDATED_EVENT, handleUpdate);
  };
}

export function getBlossomNotesSnapshot(): BlossomNote[] {
  ensureInitialized();

  return cachedNotes;
}

export function getServerBlossomNotesSnapshot(): BlossomNote[] {
  return EMPTY_NOTES;
}

export function addBlossomNote(note: BlossomNote): boolean {
  ensureInitialized();

  cachedNotes = sortNotes([note, ...cachedNotes]);

  let saved = true;

  try {
    window.localStorage.setItem(
      BLOSSOMS_STORAGE_KEY,
      JSON.stringify(cachedNotes)
    );
  } catch {
    saved = false;
  }

  window.dispatchEvent(new Event(BLOSSOMS_UPDATED_EVENT));

  return saved;
}
