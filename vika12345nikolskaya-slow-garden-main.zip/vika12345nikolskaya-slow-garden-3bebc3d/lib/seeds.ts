export type Seed = {
  id: string;
  text: string;
  plantedAt: string;
};

const SEEDS_STORAGE_KEY = "sad-semena-v1";
const SEEDS_UPDATED_EVENT = "sad-semena-updated";
const EMPTY_SEEDS: Seed[] = [];

export const MAX_SEED_LENGTH = 160;

export const seedPresets = [
  "Усталость",
  "Тревога",
  "Выгорание",
  "Не знаю, чего хочу",
  "Слишком спешу",
  "Всё хорошо, но пусто",
] as const;

export function isSeed(value: unknown): value is Seed {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const seed = value as Record<string, unknown>;

  return (
    typeof seed.id === "string" &&
    typeof seed.text === "string" &&
    typeof seed.plantedAt === "string"
  );
}

export function formatSeedDate(isoDate: string): string {
  const date = new Date(isoDate);

  if (Number.isNaN(date.getTime())) {
    return "дата не записалась";
  }

  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

let cachedSeeds: Seed[] = EMPTY_SEEDS;
let isInitialized = false;

function parseSeeds(raw: string | null): Seed[] {
  if (!raw) {
    return EMPTY_SEEDS;
  }

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed) ? parsed.filter(isSeed) : EMPTY_SEEDS;
  } catch {
    return EMPTY_SEEDS;
  }
}

function readSeedsFromStorage(): Seed[] {
  try {
    return parseSeeds(window.localStorage.getItem(SEEDS_STORAGE_KEY));
  } catch {
    return EMPTY_SEEDS;
  }
}

function ensureInitialized() {
  if (isInitialized) {
    return;
  }

  cachedSeeds = readSeedsFromStorage();
  isInitialized = true;
}

export function subscribeSeeds(onChange: () => void): () => void {
  ensureInitialized();

  const handleStorage = (event: StorageEvent) => {
    if (event.key !== null && event.key !== SEEDS_STORAGE_KEY) {
      return;
    }

    cachedSeeds = parseSeeds(event.newValue);
    onChange();
  };

  const handleUpdate = () => {
    onChange();
  };

  window.addEventListener("storage", handleStorage);
  window.addEventListener(SEEDS_UPDATED_EVENT, handleUpdate);

  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(SEEDS_UPDATED_EVENT, handleUpdate);
  };
}

export function getSeedsSnapshot(): Seed[] {
  ensureInitialized();

  return cachedSeeds;
}

export function getServerSeedsSnapshot(): Seed[] {
  return EMPTY_SEEDS;
}

export function addSeed(seed: Seed): boolean {
  ensureInitialized();

  cachedSeeds = [seed, ...cachedSeeds];

  let saved = true;

  try {
    window.localStorage.setItem(SEEDS_STORAGE_KEY, JSON.stringify(cachedSeeds));
  } catch {
    saved = false;
  }

  window.dispatchEvent(new Event(SEEDS_UPDATED_EVENT));

  return saved;
}
