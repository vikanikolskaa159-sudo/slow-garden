export type WeedBelief = {
  id: string;
  belief: string;
  explanation: string;
  reframe: string;
};

export type WeedEntry = {
  id: string;
  belief: string;
  reframe: string;
  weededAt: string;
};

export const MAX_BELIEF_LENGTH = 220;
export const MAX_REFRAME_LENGTH = 260;

export const weedBeliefs: WeedBelief[] = [
  {
    id: "too-slow",
    belief: "Я слишком медленный",
    explanation:
      "Такая мысль сравнивает ваш шаг с чьим-то другим и превращает любую паузу в доказательство. Она не оставляет места тому, что темп зависит от усталости, обстоятельств и нагрузки. Мысль звучит как факт, хотя это скорее привычная мерка.",
    reframe:
      "Я двигаюсь в своём темпе. Мой шаг может быть небольшим и всё равно настоящим.",
  },
  {
    id: "too-late",
    belief: "Мне уже поздно",
    explanation:
      "Эта мысль будто закрывает календарь и оставляет один правильный срок. Она появляется особенно часто, когда внутри мало сил или страшно начинать. Но время не перестаёт быть временем только потому, что что-то не случилось раньше.",
    reframe:
      "У меня ещё есть время. Не всё должно было случиться раньше, чтобы быть возможным сейчас.",
  },
  {
    id: "if-i-stop",
    belief: "Если я остановлюсь, всё развалится",
    explanation:
      "Так мысль путает отдых с отказом от себя и держит напряжение как страховку. Ей кажется, что всё держится только на вашем усилии. На самом деле пауза не отменяет ни вас, ни то, что уже сложилось.",
    reframe:
      "Я могу сделать паузу. Отдых не разрушает то, что важно, а возвращает мне силы быть рядом с этим.",
  },
  {
    id: "not-coping",
    belief: "Я не справляюсь",
    explanation:
      "Эта мысль обобщает трудный момент до размера всей жизни. Обычно она становится громче всего тогда, когда ресурса и так мало. Она говорит о нагрузке, но делает вид, что говорит о вас целиком.",
    reframe:
      "Сейчас мне трудно. Это говорит о нагрузке, а не о том, какой я человек.",
  },
  {
    id: "no-mistakes",
    belief: "Мне нельзя ошибаться",
    explanation:
      "Такая мысль превращает ошибку в приговор и пытается уберечь от стыда через контроль. Но чем меньше места остаётся на промах, тем труднее учиться и пробовать. Ошибка — это событие, а не оценка всей вашей ценности.",
    reframe:
      "Я могу ошибаться. Ошибка — не приговор, а часть пути, на котором я узнаю себя.",
  },
  {
    id: "be-convenient",
    belief: "Я должен быть удобным для других",
    explanation:
      "Эта мысль делает чужой комфорт вашей единственной ответственностью. Она учит делать себя меньше, чтобы рядом было спокойнее. Но забота о других не требует исчезать из собственной жизни.",
    reframe:
      "Я могу заботиться о других и при этом помнить о себе. Мои границы не делают меня плохим.",
  },
  {
    id: "feelings-exaggerated",
    belief: "Мои чувства — это преувеличение",
    explanation:
      "Так мысль пытается защитить от лишней тяжести, обесценивая сигнал. Чувства при этом не исчезают, а остаются без внимания. Им можно верить, не требуя от себя немедленного решения.",
    reframe:
      "Мои чувства имеют значение. Я могу замечать их без спешки и без осуждения.",
  },
];

export const customBeliefId = "custom";

export function findWeedBelief(id: string): WeedBelief | null {
  return weedBeliefs.find((item) => item.id === id) ?? null;
}

function cleanBelief(belief: string): string {
  return belief.trim().replace(/[.!?]+$/, "");
}

export function buildCustomResponse(belief: string): {
  explanation: string;
  reframe: string;
} {
  const cleaned = cleanBelief(belief);

  return {
    explanation:
      "Такая мысль обычно появляется, когда накопилась усталость и хочется уберечь себя от лишнего. Она звучит строго, будто уже знает ответ, но это лишь одна из мыслей, а не весь опыт. Её можно заметить и сказать себе иначе, не торопя себя.",
    reframe: `Я замечаю мысль, что «${cleaned}». Это мысль, а не факт. У неё есть причина, и я могу отнестись к ней мягче.`,
  };
}

export function isWeedEntry(value: unknown): value is WeedEntry {
  if (typeof value !== "object" || value === null) {
    return false;
  }

  const entry = value as Record<string, unknown>;

  return (
    typeof entry.id === "string" &&
    typeof entry.belief === "string" &&
    typeof entry.reframe === "string" &&
    typeof entry.weededAt === "string"
  );
}

export function formatWeedDate(isoDate: string): string {
  const date = new Date(isoDate);

  if (Number.isNaN(date.getTime())) {
    return "дата не записалась";
  }

  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

const WEEDS_STORAGE_KEY = "sad-sornyaki-v1";
const WEEDS_UPDATED_EVENT = "sad-sornyaki-updated";
const EMPTY_ENTRIES: WeedEntry[] = [];

let cachedEntries: WeedEntry[] = EMPTY_ENTRIES;
let isInitialized = false;

function parseEntries(raw: string | null): WeedEntry[] {
  if (!raw) {
    return EMPTY_ENTRIES;
  }

  try {
    const parsed: unknown = JSON.parse(raw);

    return Array.isArray(parsed) ? parsed.filter(isWeedEntry) : EMPTY_ENTRIES;
  } catch {
    return EMPTY_ENTRIES;
  }
}

function readEntriesFromStorage(): WeedEntry[] {
  try {
    return parseEntries(window.localStorage.getItem(WEEDS_STORAGE_KEY));
  } catch {
    return EMPTY_ENTRIES;
  }
}

function ensureInitialized() {
  if (isInitialized) {
    return;
  }

  cachedEntries = readEntriesFromStorage();
  isInitialized = true;
}

export function subscribeWeedEntries(onChange: () => void): () => void {
  ensureInitialized();

  const handleStorage = (event: StorageEvent) => {
    if (event.key !== null && event.key !== WEEDS_STORAGE_KEY) {
      return;
    }

    cachedEntries = parseEntries(event.newValue);
    onChange();
  };

  const handleUpdate = () => {
    onChange();
  };

  window.addEventListener("storage", handleStorage);
  window.addEventListener(WEEDS_UPDATED_EVENT, handleUpdate);

  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(WEEDS_UPDATED_EVENT, handleUpdate);
  };
}

export function getWeedEntriesSnapshot(): WeedEntry[] {
  ensureInitialized();

  return cachedEntries;
}

export function getServerWeedEntriesSnapshot(): WeedEntry[] {
  return EMPTY_ENTRIES;
}

export function addWeedEntry(entry: WeedEntry): boolean {
  ensureInitialized();

  cachedEntries = [entry, ...cachedEntries];

  let saved = true;

  try {
    window.localStorage.setItem(
      WEEDS_STORAGE_KEY,
      JSON.stringify(cachedEntries)
    );
  } catch {
    saved = false;
  }

  window.dispatchEvent(new Event(WEEDS_UPDATED_EVENT));

  return saved;
}
