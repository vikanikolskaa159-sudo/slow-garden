export type WateringSummary = {
  totalDays: number;
  currentStreak: number;
  wateredToday: boolean;
  lastDate: string | null;
  daysSinceLast: number | null;
  hasMissedDays: boolean;
};

const WATERING_STORAGE_KEY = "sad-poliv-v1";
const WATERING_UPDATED_EVENT = "sad-poliv-updated";
const EMPTY_DATES: string[] = [];
const DATE_KEY_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

const dateFormatter = new Intl.DateTimeFormat("ru-RU", {
  day: "numeric",
  month: "long",
  timeZone: "UTC",
});

const weekdayFormatter = new Intl.DateTimeFormat("ru-RU", {
  weekday: "short",
  timeZone: "UTC",
});

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

function parseDateKey(key: string): Date | null {
  const match = DATE_KEY_PATTERN.exec(key);

  if (!match) {
    return null;
  }

  const date = new Date(
    Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
  );

  return Number.isNaN(date.getTime()) ? null : date;
}

function isDateKey(value: unknown): value is string {
  return typeof value === "string" && DATE_KEY_PATTERN.test(value);
}

function daysBetween(fromKey: string, toKey: string): number {
  const from = parseDateKey(fromKey);
  const to = parseDateKey(toKey);

  if (!from || !to) {
    return 0;
  }

  return Math.round((to.getTime() - from.getTime()) / 86_400_000);
}

export function getTodayKey(date = new Date()): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function shiftDateKey(key: string, days: number): string {
  const date = parseDateKey(key);

  if (!date) {
    return key;
  }

  date.setUTCDate(date.getUTCDate() + days);

  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(
    date.getUTCDate()
  )}`;
}

export function getRecentDateKeys(todayKey: string, count: number): string[] {
  return Array.from({ length: count }, (_, index) =>
    shiftDateKey(todayKey, index - (count - 1))
  );
}

export function formatWateringDate(key: string): string {
  const date = parseDateKey(key);

  return date ? dateFormatter.format(date) : "";
}

export function formatWeekday(key: string): string {
  const date = parseDateKey(key);

  return date ? weekdayFormatter.format(date) : "";
}

export function pluralDays(value: number): string {
  const mod10 = value % 10;
  const mod100 = value % 100;

  if (mod10 === 1 && mod100 !== 11) {
    return "день";
  }

  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
    return "дня";
  }

  return "дней";
}

export function getWateringSummary(
  dates: string[],
  todayKey = getTodayKey()
): WateringSummary {
  const unique = Array.from(new Set(dates.filter(isDateKey))).sort();
  const set = new Set(unique);
  const totalDays = unique.length;
  const wateredToday = set.has(todayKey);
  const yesterdayKey = shiftDateKey(todayKey, -1);
  let cursor: string | null = wateredToday
    ? todayKey
    : set.has(yesterdayKey)
      ? yesterdayKey
      : null;
  let currentStreak = 0;

  while (cursor && set.has(cursor)) {
    currentStreak += 1;
    cursor = shiftDateKey(cursor, -1);
  }

  const pastDates = unique.filter((date) => date <= todayKey);
  const lastDate =
    pastDates.length > 0 ? pastDates[pastDates.length - 1] : null;
  const daysSinceLast = lastDate
    ? Math.max(0, daysBetween(lastDate, todayKey))
    : null;

  return {
    totalDays,
    currentStreak,
    wateredToday,
    lastDate,
    daysSinceLast,
    hasMissedDays: daysSinceLast !== null && daysSinceLast >= 2,
  };
}

function parseDates(raw: string | null): string[] {
  if (!raw) {
    return EMPTY_DATES;
  }

  try {
    const parsed: unknown = JSON.parse(raw);

    if (!Array.isArray(parsed)) {
      return EMPTY_DATES;
    }

    return Array.from(new Set(parsed.filter(isDateKey))).sort();
  } catch {
    return EMPTY_DATES;
  }
}

let cachedDates: string[] = EMPTY_DATES;
let isInitialized = false;

function readDatesFromStorage(): string[] {
  try {
    return parseDates(window.localStorage.getItem(WATERING_STORAGE_KEY));
  } catch {
    return EMPTY_DATES;
  }
}

function ensureInitialized() {
  if (isInitialized) {
    return;
  }

  cachedDates = readDatesFromStorage();
  isInitialized = true;
}

export function subscribeWatering(onChange: () => void): () => void {
  ensureInitialized();

  const handleStorage = (event: StorageEvent) => {
    if (event.key !== null && event.key !== WATERING_STORAGE_KEY) {
      return;
    }

    cachedDates = parseDates(event.newValue);
    onChange();
  };

  const handleUpdate = () => {
    onChange();
  };

  window.addEventListener("storage", handleStorage);
  window.addEventListener(WATERING_UPDATED_EVENT, handleUpdate);

  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(WATERING_UPDATED_EVENT, handleUpdate);
  };
}

export function getWateringSnapshot(): string[] {
  ensureInitialized();

  return cachedDates;
}

export function getServerWateringSnapshot(): string[] {
  return EMPTY_DATES;
}

export function markWateredToday(): {
  saved: boolean;
  alreadyMarked: boolean;
} {
  ensureInitialized();

  const todayKey = getTodayKey();

  if (cachedDates.includes(todayKey)) {
    return { saved: true, alreadyMarked: true };
  }

  cachedDates = [...cachedDates, todayKey].sort();

  let saved = true;

  try {
    window.localStorage.setItem(
      WATERING_STORAGE_KEY,
      JSON.stringify(cachedDates)
    );
  } catch {
    saved = false;
  }

  window.dispatchEvent(new Event(WATERING_UPDATED_EVENT));

  return { saved, alreadyMarked: false };
}
