export type GardenZone = {
  slug: string;
  href: string;
  name: string;
  role: string;
  description: string;
  promise: string;
};

export const gardenZones: GardenZone[] = [
  {
    slug: "semena",
    href: "/semena",
    name: "Семена",
    role: "начало пути",
    description:
      "С чем вы пришли и что хочется посадить. Здесь можно выбрать состояние или написать своё — без правильного ответа и без спешки.",
    promise:
      "Здесь появится место для первого семени и для того, с чем вы пришли сегодня.",
  },
  {
    slug: "poliv",
    href: "/poliv",
    name: "Полив",
    role: "ежедневные практики",
    description:
      "Короткие практики на две-пять минут: дыхание, пауза в теле, добрый вопрос к себе. Один маленький шаг, без обязанности.",
    promise:
      "Здесь появятся короткие практики на пару минут и спокойная отметка «полил сегодня».",
  },
  {
    slug: "sornyaki",
    href: "/sornyaki",
    name: "Сорняки",
    role: "работа с ограничивающими убеждениями",
    description:
      "Заметить мысль, которая мешает, и найти более бережную формулировку вместо неё. Без обвинений и давления.",
    promise:
      "Здесь можно будет заметить убеждение, которое мешает, и подобрать к нему более мягкие слова.",
  },
  {
    slug: "tsvetenie",
    href: "/tsvetenie",
    name: "Цветение",
    role: "истории прогресса",
    description:
      "Маленькие сдвиги, истории других людей и ваши заметки о том, что выросло само. Гербарий наблюдений, а не отчёт.",
    promise:
      "Здесь соберутся истории о маленьких сдвигах и ваши собственные заметки о том, что выросло.",
  },
];

export function getGardenZone(slug: string): GardenZone {
  const zone = gardenZones.find((item) => item.slug === slug);

  if (!zone) {
    throw new Error(`Unknown garden zone: ${slug}`);
  }

  return zone;
}
