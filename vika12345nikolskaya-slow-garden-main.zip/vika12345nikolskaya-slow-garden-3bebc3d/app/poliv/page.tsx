import type { Metadata } from "next";

import { WateringPractices } from "@/components/watering-practices";
import { getGardenZone } from "@/lib/garden";

const zone = getGardenZone("poliv");

export const metadata: Metadata = {
  title: `${zone.name} — ${zone.role}`,
  description: zone.description,
};

export default function PolivPage() {
  return <WateringPractices />;
}
