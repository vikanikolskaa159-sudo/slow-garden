import Link from "next/link";
import { ArrowRight, Droplets, Flower2, Leaf, Sprout, Sun } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { gardenZones } from "@/lib/garden";

const zoneIcons = {
  semena: Sprout,
  poliv: Droplets,
  sornyaki: Leaf,
  tsvetenie: Flower2,
} as const;

const legend = [
  "Одна женщина посадила сад. Она всё рассчитала: розы ждала к маю, пионы — к июню. Ей хотелось, чтобы красота пришла вовремя, по расписанию, которое она держала в голове.",
  "Но сад повёл себя иначе. Розы зацвели в августе. Пионы — в апреле. Не по её календарю, а по своему.",
  "Сначала она злилась. Ей казалось, что сад опаздывает, не старается, делает всё не так. Она приходила к грядкам с чувством несправедливости и считала дни.",
  "А потом — не сразу, а понемногу — она заметила: сад не опаздывает. У него просто свой ритм. Та же земля, то же солнце, но у каждого ростка своё время.",
  "Тогда она перестала ждать. Не перестала заботиться — просто перестала торопить. Она начала просто поливать: утром, без расчёта на скорый результат и без упрёков за то, что вчера было не так.",
  "Через год на её земле выросли цветы, которых она не сажала. Она не знала их названий. Но они оказались самыми красивыми — возможно, именно потому, что пришли сами.",
];

function GardenIllustration() {
  return (
    <div className="relative mx-auto w-full max-w-md animate-in fade-in slide-in-from-bottom-4 duration-1000">
      <div
        className="absolute -inset-6 rounded-[3rem] bg-accent/30 blur-2xl"
        aria-hidden="true"
      />
      <div className="relative overflow-hidden rounded-[2.5rem] border border-border/70 bg-card/70 p-5 shadow-[0_30px_60px_-30px_rgba(58,74,54,0.35)] sm:p-6">
        <svg
          viewBox="0 0 460 460"
          role="img"
          aria-label="Тихий сад на рассвете: арка, солнце и четыре ростка"
          className="h-auto w-full"
        >
          <defs>
            <linearGradient id="garden-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#e6edde" />
              <stop offset="100%" stopColor="#f7f1e2" />
            </linearGradient>
            <linearGradient id="garden-ground" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#dfe5d5" />
              <stop offset="100%" stopColor="#cfd8c4" />
            </linearGradient>
          </defs>

          <path
            d="M78 400 L78 200 C78 116 146 48 230 48 C314 48 382 116 382 200 L382 400 Z"
            fill="url(#garden-sky)"
          />
          <path
            d="M98 400 L98 202 C98 128 157 68 230 68 C303 68 362 128 362 202 L362 400"
            fill="none"
            stroke="#b9c6ae"
            strokeOpacity="0.7"
            strokeWidth="1.5"
          />
          <circle cx="298" cy="150" r="40" fill="#ead8ae" />
          <circle
            cx="298"
            cy="150"
            r="54"
            fill="none"
            stroke="#ead8ae"
            strokeOpacity="0.35"
            strokeWidth="1.5"
          />

          <path
            d="M78 344 C146 318 210 334 260 326 C312 318 354 330 382 340 L382 400 L78 400 Z"
            fill="#e8ecdf"
          />
          <path
            d="M78 400 C150 370 320 372 382 400 Z"
            fill="url(#garden-ground)"
          />

          <g stroke="#6f8b6a" strokeWidth="3" strokeLinecap="round" fill="none">
            <path d="M148 382 C148 356 146 340 152 322" />
            <path d="M208 384 C208 340 206 306 214 274" />
            <path d="M264 384 C264 352 268 326 260 298" />
            <path d="M322 384 C322 346 326 316 318 286" />
          </g>

          <g fill="#93ab8b">
            <ellipse
              cx="141"
              cy="344"
              rx="13"
              ry="6"
              transform="rotate(-28 141 344)"
            />
            <ellipse
              cx="160"
              cy="334"
              rx="12"
              ry="5.5"
              transform="rotate(24 160 334)"
            />
            <ellipse
              cx="199"
              cy="316"
              rx="15"
              ry="7"
              transform="rotate(-30 199 316)"
            />
            <ellipse
              cx="222"
              cy="298"
              rx="14"
              ry="6.5"
              transform="rotate(26 222 298)"
            />
            <ellipse
              cx="253"
              cy="342"
              rx="15"
              ry="7"
              transform="rotate(-26 253 342)"
            />
            <ellipse
              cx="274"
              cy="326"
              rx="13"
              ry="6"
              transform="rotate(28 274 326)"
            />
            <ellipse
              cx="311"
              cy="318"
              rx="15"
              ry="7"
              transform="rotate(-28 311 318)"
            />
            <ellipse
              cx="332"
              cy="300"
              rx="14"
              ry="6.5"
              transform="rotate(26 332 300)"
            />
          </g>

          <g fill="#d7b3a3">
            <circle cx="214" cy="266" r="7" />
            <circle cx="204" cy="274" r="6" />
            <circle cx="224" cy="274" r="6" />
            <circle cx="209" cy="283" r="6" />
            <circle cx="219" cy="283" r="6" />
          </g>
          <circle cx="214" cy="276" r="4" fill="#f4ead6" />

          <g fill="#c7d2bb">
            <circle cx="260" cy="291" r="6" />
            <circle cx="251" cy="298" r="5" />
            <circle cx="269" cy="298" r="5" />
            <circle cx="255" cy="306" r="5" />
            <circle cx="265" cy="306" r="5" />
          </g>
          <circle cx="260" cy="300" r="3.5" fill="#f4ead6" />

          <circle cx="318" cy="278" r="5.5" fill="#d7b3a3" />
          <circle cx="328" cy="286" r="4.5" fill="#d7b3a3" />
          <circle cx="317" cy="290" r="4" fill="#d7b3a3" />

          <g fill="#b9c6ae" opacity="0.75">
            <circle cx="178" cy="230" r="2.5" />
            <circle cx="286" cy="214" r="2.5" />
            <circle cx="338" cy="236" r="2" />
            <circle cx="132" cy="260" r="2" />
          </g>
        </svg>

        <div className="mt-4 flex items-center justify-between gap-4 text-xs text-muted-foreground">
          <span>утро в саду</span>
          <span className="inline-flex items-center gap-1.5">
            <Sun className="h-3.5 w-3.5" aria-hidden="true" />
            свой ритм
          </span>
        </div>
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <div className="overflow-hidden">
      <section className="relative">
        <div className="container mx-auto max-w-6xl px-4 pb-20 pt-14 sm:pb-28 sm:pt-20">
          <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <Badge
                variant="outline"
                className="h-auto gap-2 rounded-full border-primary/25 bg-card/60 px-3.5 py-1.5 text-xs font-normal tracking-wide text-muted-foreground"
              >
                <Leaf className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
                тихий ботанический дневник
              </Badge>

              <div className="space-y-5">
                <h1 className="font-heading text-4xl leading-[1.08] tracking-tight text-balance sm:text-5xl lg:text-6xl">
                  Сад, который
                  <br className="hidden sm:block" /> не цветёт по расписанию
                </h1>
                <p className="max-w-xl text-lg leading-relaxed text-muted-foreground">
                  Место, где можно не спешить. Здесь изменения растут в своём
                  темпе — как в саду, где у каждого ростка своё время.
                </p>
              </div>

              <p className="max-w-xl border-l-2 border-primary/35 pl-4 text-base leading-relaxed text-foreground/85 sm:text-lg">
                Сад не опаздывает. Идти можно в любом порядке и в своём темпе —
                так, как получается сегодня.
              </p>

              <div className="flex flex-wrap items-center gap-3">
                <Link
                  href="#map"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-sm transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
                >
                  Пройти по карте сада
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
                <Link
                  href="/semena"
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-border/80 bg-card/60 px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-card focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
                >
                  Посадить первое семя
                </Link>
              </div>
            </div>

            <GardenIllustration />
          </div>
        </div>
      </section>

      <section className="border-y border-border/60 bg-secondary/35">
        <div className="container mx-auto max-w-6xl px-4 py-16 sm:py-24">
          <div className="grid gap-10 lg:grid-cols-[0.65fr_1.35fr] lg:gap-16">
            <div className="space-y-5 lg:sticky lg:top-24 lg:self-start">
              <p className="text-xs uppercase tracking-[0.24em] text-primary/80">
                легенда
              </p>
              <h2 className="font-heading text-3xl leading-tight tracking-tight text-balance sm:text-4xl">
                История одного сада
              </h2>
              <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
                Короткая история о том, почему здесь не торопят и не считают
                опоздания.
              </p>
              <div className="hidden items-center gap-3 pt-2 text-primary/60 lg:flex">
                <span className="h-px w-10 bg-primary/30" />
                <Sprout className="h-5 w-5" aria-hidden="true" />
              </div>
            </div>

            <article className="space-y-5 text-[1.02rem] leading-8 text-foreground/85 animate-in fade-in slide-in-from-bottom-4 duration-700">
              {legend.map((paragraph) => (
                <p key={paragraph.slice(0, 24)}>{paragraph}</p>
              ))}
              <blockquote className="mt-8 border-l-2 border-primary/30 pl-5 font-heading text-xl leading-relaxed text-foreground sm:text-2xl">
                «Сад не опаздывает. Просто у него свой ритм».
              </blockquote>
            </article>
          </div>
        </div>
      </section>

      <section id="map" className="scroll-mt-20">
        <div className="container mx-auto max-w-6xl px-4 py-16 sm:py-24">
          <div className="mx-auto max-w-2xl space-y-4 text-center">
            <p className="text-xs uppercase tracking-[0.24em] text-primary/80">
              карта сада
            </p>
            <h2 className="font-heading text-3xl leading-tight tracking-tight text-balance sm:text-4xl">
              Четыре зоны, четыре способа побыть с собой
            </h2>
            <p className="text-base leading-relaxed text-muted-foreground">
              Заходите в любую — порядок не важен. Можно гулять по одной зоне,
              можно возвращаться и начинать заново.
            </p>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            {gardenZones.map((zone, index) => {
              const Icon = zoneIcons[zone.slug as keyof typeof zoneIcons];

              return (
                <Link
                  key={zone.slug}
                  href={zone.href}
                  className="group relative flex flex-col justify-between gap-6 rounded-3xl border border-border/70 bg-card/80 p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-[0_18px_40px_-24px_rgba(58,74,54,0.45)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 sm:p-7"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-accent/60 text-accent-foreground transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
                      <Icon className="h-6 w-6" aria-hidden="true" />
                    </div>
                    <span className="font-heading text-sm text-muted-foreground/70">
                      0{index + 1}
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                      <h3 className="font-heading text-2xl tracking-tight">
                        {zone.name}
                      </h3>
                      <span className="text-xs leading-relaxed text-muted-foreground">
                        {zone.role}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {zone.description}
                    </p>
                  </div>

                  <span className="inline-flex items-center gap-2 text-sm font-medium text-primary">
                    Зайти в зону
                    <ArrowRight
                      className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                      aria-hidden="true"
                    />
                  </span>
                </Link>
              );
            })}
          </div>

          <div className="mx-auto mt-12 max-w-2xl rounded-3xl border border-primary/15 bg-accent/35 px-6 py-6 text-center">
            <p className="font-heading text-lg leading-relaxed text-foreground sm:text-xl">
              Сад не опаздывает. Идти можно в любом порядке и в своём темпе.
            </p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Здесь не нужно успевать и не нужно выбирать правильную зону.
              Достаточно заглянуть туда, куда тянется сейчас.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
