import type { Metadata } from "next";

import { WeedGarden } from "@/components/weed-garden";
import { getGardenZone } from "@/lib/garden";

const zone = getGardenZone("sornyaki");

export const metadata: Metadata = {
  title: `${zone.name} — ${zone.role}`,
  description: zone.description,
};

export default function SornyakiPage() {
  return <WeedGarden />;
}
