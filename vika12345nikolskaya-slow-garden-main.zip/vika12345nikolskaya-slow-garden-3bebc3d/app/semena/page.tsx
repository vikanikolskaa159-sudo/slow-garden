import type { Metadata } from "next";

import { SeedGarden } from "@/components/seed-garden";
import { getGardenZone } from "@/lib/garden";

const zone = getGardenZone("semena");

export const metadata: Metadata = {
  title: `${zone.name} — ${zone.role}`,
  description: zone.description,
};

export default function SemenaPage() {
  return <SeedGarden />;
}
