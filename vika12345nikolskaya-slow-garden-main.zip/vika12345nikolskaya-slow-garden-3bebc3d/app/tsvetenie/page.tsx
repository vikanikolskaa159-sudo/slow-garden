import type { Metadata } from "next";

import { BlossomGarden } from "@/components/blossom-garden";
import { getGardenZone } from "@/lib/garden";

const zone = getGardenZone("tsvetenie");

export const metadata: Metadata = {
  title: `${zone.name} — ${zone.role}`,
  description: zone.description,
};

export default function TsveteniePage() {
  return <BlossomGarden />;
}
