import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { Geist } from "next/font/google";
import { cn } from "@/lib/utils";
import { Sprout } from "lucide-react";
import { BridgeProvider } from "@/components/bridge-provider";
import { Toaster } from "@/components/ui/sonner";

const geist = Geist({ subsets: ["latin"], variable: "--font-sans" });

const appName = "Сад, который не цветёт по расписанию";

export const metadata: Metadata = {
  title: appName,
  description:
    "Тихий сад для тех, кто устал себя торопить: легенда, четыре зоны и маленькие шаги в своём темпе.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" className={cn("font-sans", geist.variable)}>
      <body className="antialiased min-h-screen bg-background flex flex-col">
        <BridgeProvider />
        <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur-md">
          <div className="container mx-auto flex h-14 items-center px-4">
            <Link
              href="/"
              className="flex items-center gap-2.5 text-sm font-medium tracking-tight sm:text-lg"
            >
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <Sprout className="h-4 w-4" aria-hidden="true" />
              </div>
              <span className="leading-tight">{appName}</span>
            </Link>
          </div>
        </header>
        <main className="flex-1">{children}</main>
        <footer className="border-t border-border/60 bg-secondary/30">
          <div className="container mx-auto max-w-2xl px-4 py-8 text-center text-xs leading-relaxed text-muted-foreground">
            <p>
              © {new Date().getFullYear()} {appName}
            </p>
            <p className="mt-2">
              Сайт не заменяет терапию и консультации специалиста. Если сейчас
              тяжело, рядом могут быть близкие или психолог.
            </p>
          </div>
        </footer>
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
